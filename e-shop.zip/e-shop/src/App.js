import React from 'react'
import Shop from './shop/index.jsx'

const App = () => {
  return <>
    <Shop />
  </>
}

export default App;
