import React, { Component } from 'react'

class Footer extends Component {
    render() {
        return <div className="text-center p-4 text-dark bg-light">
            <h5>Copyright &copy; Jobayer Hossain </h5>
        </div>
    }
}

export default Footer